import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Container, Card, Form, Button, Alert, Spinner, Navbar } from 'react-bootstrap';

const API_URL = 'http://localhost:9000';

function SubjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [subject, setSubject] = useState(null);
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    curriculum: '',
    semester: '',
    credits: '',
    preRequisites: '',
    description: ''
  });
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    const user = localStorage.getItem('user');
    if (!user) {
      navigate('/login');
      return;
    }
    fetchSubjectDetail();
  }, [id, navigate]);

  const parsePreRequisitesToString = (preReqs) => {
    if (!preReqs) return '';
    let list = [];
    if (Array.isArray(preReqs)) {
      list = preReqs.flatMap((item) =>
        typeof item === 'string' ? item.split(/[;,]/) : item
      );
    } else if (typeof preReqs === 'string') {
      list = preReqs.split(/[;,]/);
    }
    list = list.map((s) => String(s).trim()).filter(Boolean);
    return list.join(', ');
  };

  const fetchSubjectDetail = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_URL}/subjects/${id}`);
      const data = response.data;
      setSubject(data);
      setFormData({
        code: data.code || '',
        name: data.name || '',
        curriculum: data.curriculum || '',
        semester: data.semester !== undefined ? data.semester : '',
        credits: data.credits !== undefined ? data.credits : '',
        preRequisites: parsePreRequisitesToString(data.preRequisites),
        description: data.description || ''
      });
      setLoading(false);
    } catch (err) {
      console.error(err);
      setError('Failed to fetch subject details.');
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEditSave = async () => {
    if (!isEditing) {
      setIsEditing(true);
      setSuccessMsg('');
      return;
    }

    // Save changes to API
    try {
      const preReqArray = formData.preRequisites
        ? formData.preRequisites
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean)
        : [];

      const updatedData = {
        ...subject,
        code: formData.code,
        name: formData.name,
        curriculum: formData.curriculum,
        semester: Number(formData.semester),
        credits: Number(formData.credits),
        preRequisites: preReqArray,
        description: formData.description
      };

      await axios.put(`${API_URL}/subjects/${id}`, updatedData);
      setSubject(updatedData);
      setIsEditing(false);
      setSuccessMsg('Subject updated successfully!');
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err) {
      console.error(err);
      setError('Failed to save subject details.');
    }
  };

  const handleDelete = async () => {
    const confirmed = window.confirm('Are you sure you want to delete this subject?');
    if (!confirmed) return;

    try {
      await axios.delete(`${API_URL}/subjects/${id}`);
      navigate('/syllabus');
    } catch (err) {
      console.error(err);
      setError('Failed to delete subject.');
    }
  };

  const readOnlyStyle = !isEditing
    ? { backgroundColor: '#e9ecef', color: '#495057', cursor: 'default' }
    : {};

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f8f9fa' }}>
      {/* Header & Navigation */}
      <Navbar bg="dark" variant="dark" expand="lg" className="py-2 px-3 shadow-sm">
        <Container fluid>
          <Navbar.Brand className="fw-semibold fs-5 text-white">
            Subject Detail Management
          </Navbar.Brand>
          <div className="ms-auto">
            <Button
              variant="outline-light"
              size="sm"
              onClick={() => navigate('/syllabus')}
              className="px-3"
            >
              Back to List
            </Button>
          </div>
        </Container>
      </Navbar>

      <Container className="py-4 d-flex justify-content-center">
        {loading ? (
          <div className="text-center py-5">
            <Spinner animation="border" variant="primary" />
          </div>
        ) : error && !subject ? (
          <Alert variant="danger">{error}</Alert>
        ) : (
          <div style={{ width: '600px', maxWidth: '100%' }}>
            <h3 className="text-center fw-bold mb-4">Subject Information</h3>

            {successMsg && <Alert variant="success">{successMsg}</Alert>}
            {error && <Alert variant="danger">{error}</Alert>}

            <Form>
              <Form.Group className="mb-3" controlId="subjectCode">
                <Form.Label className="fw-semibold">Code</Form.Label>
                <Form.Control
                  type="text"
                  name="code"
                  value={formData.code}
                  onChange={handleChange}
                  readOnly={!isEditing}
                  style={readOnlyStyle}
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="subjectName">
                <Form.Label className="fw-semibold">Name</Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  readOnly={!isEditing}
                  style={readOnlyStyle}
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="subjectCurriculum">
                <Form.Label className="fw-semibold">Curriculum</Form.Label>
                <Form.Control
                  type="text"
                  name="curriculum"
                  value={formData.curriculum}
                  onChange={handleChange}
                  readOnly={!isEditing}
                  style={readOnlyStyle}
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="subjectSemester">
                <Form.Label className="fw-semibold">Semester</Form.Label>
                <Form.Control
                  type="number"
                  name="semester"
                  value={formData.semester}
                  onChange={handleChange}
                  readOnly={!isEditing}
                  style={readOnlyStyle}
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="subjectCredits">
                <Form.Label className="fw-semibold">Credits</Form.Label>
                <Form.Control
                  type="number"
                  name="credits"
                  value={formData.credits}
                  onChange={handleChange}
                  readOnly={!isEditing}
                  style={readOnlyStyle}
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="subjectPreRequisites">
                <Form.Label className="fw-semibold">
                  Pre-requisites (cách nhau bởi dấu phẩy)
                </Form.Label>
                <Form.Control
                  type="text"
                  name="preRequisites"
                  value={formData.preRequisites}
                  onChange={handleChange}
                  readOnly={!isEditing}
                  style={readOnlyStyle}
                />
              </Form.Group>

              <Form.Group className="mb-4" controlId="subjectDescription">
                <Form.Label className="fw-semibold">Description</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  readOnly={!isEditing}
                  style={readOnlyStyle}
                />
              </Form.Group>

              {/* Action Toolbar */}
              <div className="d-flex justify-content-between mt-4">
                <Button
                  variant="secondary"
                  type="button"
                  onClick={handleEditSave}
                  className="px-4"
                  style={{ minWidth: '90px' }}
                >
                  {isEditing ? 'Save' : 'Edit'}
                </Button>
                <Button
                  variant="secondary"
                  type="button"
                  onClick={handleDelete}
                  className="px-4"
                  style={{ minWidth: '90px' }}
                >
                  Delete
                </Button>
              </div>
            </Form>
          </div>
        )}
      </Container>
    </div>
  );
}

export default SubjectDetail;

