import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar, Container, Button } from 'react-bootstrap';

function NavigationBar({ user }) {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <Navbar bg="dark" variant="dark" expand="lg" className="py-2 px-3 shadow-sm">
      <Container fluid>
        <Navbar.Brand className="fw-semibold fs-5 text-white">
          FPT Education Learning Materials Portal
        </Navbar.Brand>
        <div className="d-flex align-items-center ms-auto">
          {user && (
            <span className="text-light me-3">
              Hello, {user.fullName} ({user.role})
            </span>
          )}
          <Button
            variant="outline-light"
            size="sm"
            onClick={handleLogout}
            className="px-3"
          >
            Logout
          </Button>
        </div>
      </Container>
    </Navbar>
  );
}

export default NavigationBar;

