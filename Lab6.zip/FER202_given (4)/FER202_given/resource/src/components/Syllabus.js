import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { Container, Table, Form, Button, Row, Col, Spinner, Alert } from 'react-bootstrap';
import NavigationBar from './Navbar';

const API_URL = 'http://localhost:9000';

function Syllabus() {
  const [subjects, setSubjects] = useState([]);
  const [filteredSubjects, setFilteredSubjects] = useState([]);
  const [searchBy, setSearchBy] = useState('Code');
  const [keyword, setKeyword] = useState('');
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      navigate('/login');
      return;
    }
    try {
      setUser(JSON.parse(storedUser));
    } catch {
      localStorage.removeItem('user');
      navigate('/login');
      return;
    }
    fetchSubjects();
  }, [navigate]);

  const fetchSubjects = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_URL}/subjects`);
      setSubjects(response.data);
      setFilteredSubjects(response.data);
      setLoading(false);
    } catch (err) {
      console.error(err);
      setError('Failed to fetch subjects. Make sure mock API is running on port 9000.');
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    if (e) e.preventDefault();
    const query = keyword.trim().toLowerCase();
    if (!query) {
      setFilteredSubjects(subjects);
      return;
    }

    const filtered = subjects.filter((sub) => {
      if (searchBy === 'Code') {
        return (sub.code || '').toLowerCase().includes(query);
      } else if (searchBy === 'Name') {
        return (sub.name || '').toLowerCase().includes(query);
      }
      return true;
    });

    setFilteredSubjects(filtered);
  };

  const formatPreRequisites = (preReqs) => {
    if (!preReqs) return 'None';
    let list = [];
    if (Array.isArray(preReqs)) {
      if (preReqs.length === 0) return 'None';
      list = preReqs.flatMap((item) =>
        typeof item === 'string' ? item.split(/[;,]/) : item
      );
    } else if (typeof preReqs === 'string') {
      list = preReqs.split(/[;,]/);
    }
    list = list.map((s) => String(s).trim()).filter(Boolean);
    return list.length > 0 ? list.join(', ') : 'None';
  };

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#fff' }}>
      <NavigationBar user={user} />

      <Container className="py-4">
        <h2 className="fw-bold mb-4">Syllabus Management</h2>

        <Form onSubmit={handleSearch} className="mb-4">
          <Row className="align-items-center g-2" style={{ maxWidth: '650px' }}>
            <Col xs="auto">
              <span className="fw-semibold">Search by:</span>
            </Col>
            <Col xs="auto" style={{ width: '130px' }}>
              <Form.Select
                value={searchBy}
                onChange={(e) => setSearchBy(e.target.value)}
                size="sm"
              >
                <option value="Code">Code</option>
                <option value="Name">Name</option>
              </Form.Select>
            </Col>
            <Col style={{ minWidth: '220px' }}>
              <Form.Control
                type="text"
                placeholder="Enter keyword..."
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                size="sm"
              />
            </Col>
            <Col xs="auto">
              <Button variant="secondary" type="submit" size="sm" className="px-3">
                Search
              </Button>
            </Col>
          </Row>
        </Form>

        <h4 className="fw-bold mb-3">Subject List</h4>

        {loading ? (
          <div className="text-center py-5">
            <Spinner animation="border" variant="primary" />
          </div>
        ) : error ? (
          <Alert variant="danger">{error}</Alert>
        ) : (
          <div className="table-responsive">
            <Table bordered hover className="align-middle shadow-sm">
              <thead className="table-dark">
                <tr>
                  <th style={{ width: '10%' }}>Code</th>
                  <th style={{ width: '20%' }}>Name</th>
                  <th style={{ width: '18%' }}>Curriculum</th>
                  <th style={{ width: '8%', textAlign: 'center' }}>Semester</th>
                  <th style={{ width: '7%', textAlign: 'center' }}>Credits</th>
                  <th style={{ width: '17%' }}>Pre-requisites</th>
                  <th style={{ width: '20%' }}>Description</th>
                </tr>
              </thead>
              <tbody>
                {filteredSubjects.length > 0 ? (
                  filteredSubjects.map((sub) => (
                    <tr key={sub.id}>
                      <td>
                        <Link
                          to={`/subject/${sub.id}`}
                          className="fw-bold text-decoration-none"
                          style={{ color: '#0d6efd' }}
                        >
                          {sub.code}
                        </Link>
                      </td>
                      <td>{sub.name}</td>
                      <td>{sub.curriculum}</td>
                      <td style={{ textAlign: 'center' }}>{sub.semester}</td>
                      <td style={{ textAlign: 'center' }}>{sub.credits}</td>
                      <td>{formatPreRequisites(sub.preRequisites)}</td>
                      <td>{sub.description}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7" className="text-center py-4 text-muted">
                      No subjects found.
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
          </div>
        )}
      </Container>
    </div>
  );
}

export default Syllabus;

