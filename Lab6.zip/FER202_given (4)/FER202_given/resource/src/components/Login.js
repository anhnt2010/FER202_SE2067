import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Container, Card, Form, Button, Alert } from 'react-bootstrap';

const API_URL = 'http://localhost:9000';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const user = localStorage.getItem('user');
    if (user) {
      navigate('/syllabus');
    }
  }, [navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    try {
      const response = await axios.get(`${API_URL}/accounts`);
      const accounts = response.data;

      const account = accounts.find(
        (acc) => acc.email === email && acc.password === password
      );

      if (!account) {
        setError('Invalid email or password');
        return;
      }

      if (account.status === 'Inactive') {
        setError('Tài khoản đã bị khóa');
        return;
      }

      // Save user session into localStorage
      localStorage.setItem('user', JSON.stringify(account));
      navigate('/syllabus');
    } catch (err) {
      console.error(err);
      setError('Cannot connect to server. Please ensure json-server is running on port 9000.');
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        backgroundColor: '#eef2f5',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px'
      }}
    >
      <Container className="d-flex justify-content-center">
        <Card
          className="shadow-sm border-0"
          style={{ width: '420px', maxWidth: '100%', borderRadius: '8px' }}
        >
          <Card.Body className="p-4">
            <h3 className="text-center mb-4 fw-bold text-secondary">Sign In</h3>

            {error && (
              <Alert variant="danger" className="py-2">
                {error}
              </Alert>
            )}

            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3" controlId="formEmail">
                <Form.Label className="fw-semibold">Email</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="email of student or lecture"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </Form.Group>

              <Form.Group className="mb-4" controlId="formPassword">
                <Form.Label className="fw-semibold">Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </Form.Group>

              <Button
                variant="primary"
                type="submit"
                className="w-100 py-2 fw-semibold"
                style={{ backgroundColor: '#0d6efd', border: 'none' }}
              >
                Login
              </Button>
            </Form>
          </Card.Body>
        </Card>
      </Container>
    </div>
  );
}

export default Login;

