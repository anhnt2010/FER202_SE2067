import { useEffect, useMemo, useState } from 'react';
import GenreFilter from './components/GenreFilter.js';
import Header from './components/Header.js';
import MovieDetail from './components/MovieDetail.js';
import MoviesList from './components/MoviesList.js';
import SearchBar from './components/SearchBar.js';
import { ThemeProvider } from './context/ThemeContext.js';
import { movies } from './datas/movies.js';
import { useLocalStorage } from './hooks/useLocalStorage.js';

const ALL_GENRES = 'Tất cả thể loại';

export default function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState(ALL_GENRES);
  const [sortBy, setSortBy] = useState('default');
  const [selectedMovieId, setSelectedMovieId] = useState(movies[0]?.id ?? null);
  const [favorites, setFavorites] = useLocalStorage('movie-favorites', []);

  const genres = useMemo(
    () => [ALL_GENRES, ...new Set(movies.map((movie) => movie.genre))],
    []
  );

  const filteredMovies = useMemo(() => {
    let result = movies.filter((movie) => {
      const matchesSearch = movie.title.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesGenre = selectedGenre === ALL_GENRES || movie.genre === selectedGenre;
      return matchesSearch && matchesGenre;
    });

    if (sortBy === 'ratingHigh') {
      result = [...result].sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'ratingLow') {
      result = [...result].sort((a, b) => a.rating - b.rating);
    }

    return result;
  }, [searchTerm, selectedGenre, sortBy]);

  useEffect(() => {
    if (selectedMovieId !== null && !filteredMovies.some((m) => m.id === selectedMovieId)) {
      setSelectedMovieId(filteredMovies[0]?.id ?? null);
    }
  }, [filteredMovies, selectedMovieId]);

  const selectedMovie = movies.find((movie) => movie.id === selectedMovieId) ?? null;

  const toggleFavorite = (movieId) => {
    setFavorites((prevFavorites) =>
      prevFavorites.includes(movieId)
        ? prevFavorites.filter((id) => id !== movieId)
        : [...prevFavorites, movieId]
    );
  };

  return (
    <ThemeProvider>
      <div className="app">
        <div className="container">
          <Header />

          <div className="main-layout">
            <div className="left-panel">
              <div className="controls-row">
                <SearchBar value={searchTerm} onChange={setSearchTerm} />
                <GenreFilter
                  value={selectedGenre}
                  onChange={setSelectedGenre}
                  genres={genres}
                />
                <div className="sort-box">
                  <select
                    id="sort-order"
                    className="sort-select"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                  >
                    <option value="default">Mặc định</option>
                    <option value="ratingHigh">Rating: Cao → Thấp</option>
                    <option value="ratingLow">Rating: Thấp → Cao</option>
                  </select>
                </div>
              </div>

              <div className="stats-bar">
                <span>Tổng: {movies.length}</span>
                <span className="stats-divider">|</span>
                <span>Yêu thích: {favorites.length}</span>
                <span className="stats-divider">|</span>
                <span>Đang hiển thị: {filteredMovies.length}</span>
              </div>

              <MoviesList
                movies={filteredMovies}
                selectedMovieId={selectedMovieId}
                favorites={favorites}
                onSelectMovie={setSelectedMovieId}
                onToggleFavorite={toggleFavorite}
              />
            </div>

            <div className="right-panel">
              <MovieDetail
                movie={selectedMovie}
                onClose={() => setSelectedMovieId(null)}
              />
            </div>
          </div>
        </div>
      </div>
    </ThemeProvider>
  );
}
