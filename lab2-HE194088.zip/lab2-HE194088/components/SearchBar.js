import { useEffect, useRef } from 'react';

export default function SearchBar({ value, onChange }) {
  const searchInputRef = useRef(null);

  useEffect(() => {
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, []);

  return (
    <div className="search-box">
      <input
        ref={searchInputRef}
        id="movie-search"
        className="search-input"
        type="text"
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder="Tìm tên phim...."
      />
    </div>
  );
}
