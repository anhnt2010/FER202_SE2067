export default function GenreFilter({ value, onChange, genres }) {
  return (
    <div className="filter-box">
      <select
        id="genre-filter"
        className="filter-select"
        value={value}
        onChange={(event) => onChange(event.target.value)}
      >
        {genres.map((genre) => (
          <option key={genre} value={genre}>
            {genre}
          </option>
        ))}
      </select>
    </div>
  );
}
