import { useTheme } from '../context/ThemeContext.js';

export default function Header() {
  const { theme, setTheme } = useTheme();

  return (
    <header className="app-header">
      <h1 className="header-title"> Mini Movie Manager</h1>
      <button
        type="button"
        className="theme-toggle-btn"
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      >
        {theme === 'dark' ? '☀️ Light' : '🌙 Dark'}
      </button>
    </header>
  );
}
