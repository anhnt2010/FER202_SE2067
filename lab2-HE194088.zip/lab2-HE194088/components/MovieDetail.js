export default function MovieDetail({ movie, onClose }) {
  if (!movie) {
    return (
      <div className="movie-detail-card empty">
        <h2 className="detail-panel-title">Movie Details</h2>
        <div className="empty-state">Chọn một bộ phim để xem chi tiết.</div>
      </div>
    );
  }

  return (
    <div className="movie-detail-card">
      <h2 className="detail-panel-title">Movie Details</h2>

      <div className="detail-row">
        <span className="detail-label">Title:</span>
        <span className="detail-value title-val">{movie.title}</span>
      </div>

      <div className="detail-row">
        <span className="detail-label">Genre:</span>
        <span className="detail-value">{movie.genre}</span>
      </div>

      <div className="detail-row">
        <span className="detail-label">Year:</span>
        <span className="detail-value">{movie.year}</span>
      </div>

      <div className="detail-row">
        <span className="detail-label">Rating:</span>
        <span className="detail-value rating-val">★ {movie.rating}</span>
      </div>

      <div className="detail-row">
        <span className="detail-label">Director:</span>
        <span className="detail-value">{movie.director}</span>
      </div>

      <div className="detail-row">
        <span className="detail-label">Duration:</span>
        <span className="detail-value">{movie.duration} minutes</span>
      </div>

      <div className="detail-section">
        <span className="detail-label block">Description:</span>
        <p className="detail-desc">{movie.description}</p>
      </div>

      {onClose && (
        <div className="detail-actions">
          <button type="button" className="btn-close" onClick={onClose}>
            Close
          </button>
        </div>
      )}
    </div>
  );
}
