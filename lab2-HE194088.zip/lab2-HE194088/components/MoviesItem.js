export default function MoviesItem({ movie, isActive, isFavorite, onSelect, onToggleFavorite }) {
  return (
    <div className={`movie-item ${isActive ? 'active' : ''}`}>
      <div className="movie-item-main">
        <span className="star-indicator">{isFavorite ? '⭐' : '☆'}</span>
        <span className="movie-title-text">{movie.title}</span>
        <span className="separator">|</span>
        <span className="meta-info">{movie.genre}</span>
        <span className="separator">|</span>
        <span className="meta-info">{movie.year}</span>
        <span className="separator">|</span>
        <span className="rating-badge">★ {movie.rating}</span>
      </div>

      <div className="movie-item-actions">
        <button
          type="button"
          className={`btn-action btn-fav ${isFavorite ? 'is-fav' : ''}`}
          onClick={() => onToggleFavorite(movie.id)}
        >
          {isFavorite ? 'BỎ THÍCH' : 'YÊU THÍCH'}
        </button>
        <button
          type="button"
          className="btn-action btn-detail"
          onClick={() => onSelect(movie.id)}
        >
          CHI TIẾT
        </button>
      </div>
    </div>
  );
}
