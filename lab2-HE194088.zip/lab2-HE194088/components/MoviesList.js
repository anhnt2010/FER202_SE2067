import MoviesItem from './MoviesItem.js';

export default function MoviesList({
  movies,
  selectedMovieId,
  favorites,
  onSelectMovie,
  onToggleFavorite
}) {
  if (!movies.length) {
    return (
      <div className="movie-list">
        <div className="empty-state">Không có phim nào phù hợp với tìm kiếm.</div>
      </div>
    );
  }

  return (
    <div className="movie-list">
      <div className="list-scroll">
        {movies.map((movie) => (
          <MoviesItem
            key={movie.id}
            movie={movie}
            isActive={selectedMovieId === movie.id}
            isFavorite={favorites.includes(movie.id)}
            onSelect={onSelectMovie}
            onToggleFavorite={onToggleFavorite}
          />
        ))}
      </div>
    </div>
  );
}
