import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { products } from '../data/products';

function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const product = products.find((p) => p.id === parseInt(id, 10));

  const handleBack = () => {
    navigate('/products');
  };

  if (!product) {
    return (
      <div className="container py-4">
        <button onClick={handleBack} className="btn btn-secondary mb-3">
          Quay lại danh sách
        </button>
        <div className="alert alert-warning text-center">
          <h4>Không tìm thấy sản phẩm</h4>
          <p>Sản phẩm với ID {id} không tồn tại.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-4">
      <button onClick={handleBack} className="btn btn-secondary mb-4">
        Quay lại danh sách
      </button>

      <div className="border p-4 bg-white">
        <div className="row">
          <div className="col-md-5 mb-3 mb-md-0">
            <div
              className="border d-flex align-items-center justify-content-center text-muted bg-light"
              style={{ height: '260px' }}
            >
            </div>
          </div>
          
          <div className="col-md-7">
            <h3 className="fw-bold mb-3">{product.name}</h3>
            <p className="mb-2">
              <strong>ID:</strong> {product.id}
            </p>
            <p className="mb-2">
              <strong>Danh mục:</strong> {product.category}
            </p>
            <p className="mb-3">
              <strong>Giá:</strong> {product.price.toLocaleString('vi-VN')}đ
            </p>
            <hr />
            <p className="mb-0">
              <strong>Mô tả:</strong> {product.description}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;
