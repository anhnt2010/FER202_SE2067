import React from 'react';
import { Link } from 'react-router-dom';

function NotFound() {
  return (
    <div className="container text-center py-5">
      <div className="p-5 border bg-white mx-auto" style={{ maxWidth: '600px' }}>
        <h2 className="fw-bold mb-3">404 - Không tìm thấy trang</h2>
        <p className="text-muted mb-4">
          Trang bạn đang tìm kiếm không tồn tại.
        </p>
        <div>
          <Link to="/" className="btn btn-primary">
            Về trang chủ
          </Link>
        </div>
      </div>
    </div>
  );
}

export default NotFound;
